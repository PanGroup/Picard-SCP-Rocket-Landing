1. main_for_LSCP
(1) use MATLAB-2018 (or above)
(2) use MOSEK

2. main_for_AAPSCP
(1) use MATLAB-2018 (or above)
(2) use MOSEK
(3) set m=2 for Anderson accelerated Picard-based SCP
(4) set m=0 for Picard-based SCP
