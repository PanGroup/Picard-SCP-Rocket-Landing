function X = PicardIteration(Xk,Uk,kappa2)
global chebyParam
CoeffiA                          =  chebyParam.CoeffiA;
tau                              =  chebyParam.tau';
Num                              =  length(tau);

Xk                               =  reshape(Xk,[],Num)';
Uk                               =  reshape(Uk,[],Num)';
X                                =  Xk;

RightTerms                       =  sysModelLandingCoord3DMatrix(Xk,Uk);
X(:,4:6)                         =  X(1,4:6) + kappa2*CoeffiA*RightTerms;
X(:,1:3)                         =  X(1,1:3) + kappa2*X(1,4:6).*(tau+1) + kappa2*CoeffiA*(X(:,4:6) - X(1,4:6));
X(:,7)                           =  X(1,7) - 1/3500*kappa2*CoeffiA*Uk(:,end);
X                                =  reshape(X',[],1);


