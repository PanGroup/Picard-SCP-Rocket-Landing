%-------------------------------------------------------------------------%
% @brief         Anderson accelerated Picard iteration-based SCP for rocket landing trajectory optimization
% @author        Lance
% @date          2021.08.29
%-------------------------------------------------------------------------%
function  outputSimu             =  trajOptimAAPSCP(Num,X0,initFlag)
global modelParam chebyParam

%% Global parameters
% model parameters
massrate                         =  modelParam.massrate;
Isp                              =  modelParam.GroundIsp;
DryMass                          =  modelParam.dryMass;

% max tilt angle
GammaT                           =  modelParam.GammaT;

% Temporal nodes
tau                              =  chebyParam.tau';
CoeffiA                          =  chebyParam.CoeffiA;

%% Trajectory Optimization
NumY                             =  6;
NumX                             =  7;
NumU                             =  4;

% Terminal conditions
Ytarg                            =  [0, 1, 0, 0, -1, 0]';

% Initial conditions
T0                               =  0;
Tf                               =  30;
% load('InitCondition.mat');

% Set initial guess
if   initFlag                    == 0
    % Randomly Generated Initial Guess
    b1 = 5000;   b2 = 1000;   b3 = 5000;
    Xinit                        =  zeros(Num,NumX);
    Xinit(1,:)                   =  X0;
    Xinit(2:end,1:3)             =  2*(rand(Num-1,3)-1/2).*b1;
    Xinit(2:end,4:6)             =  2*(rand(Num-1,3)-1/2).*b2;
    Xinit(2:end,7)               =  log(23000 + 2*(rand(Num-1,1)-1/2)*b3);
    Uinit                        =  zeros(Num,NumU);
    
elseif initFlag                  == 1
    % Constant Profile
    Xinit                        =  repmat(X0,Num,1);
    Uinit                        =  zeros(Num,NumU); 
    Xinit(1,:)                   =  X0;
    
elseif initFlag                  == 2
    % Linear Interpolation
    Xinit                        =  interp1([-1;1],[X0;[Ytarg;log(DryMass)]'],tau');
    Uinit                        =  zeros(Num,NumU);
    
else
    % Error
    disp('Error in initial Guess!');
    
end

X                                =  Xinit;
U                                =  Uinit;
kappa2                           =  (Tf - T0)/2;

iter                             =  0;
tic
while true

    % Previous solution
    Xpre                         =  X;

    % H-matrix
    [HrN, HvN, HzN]              =  calcuH(Xpre,T0,Tf);
    
    % clear MOSEK
    clear prob;
    
    % Performance index
    % J = Max Zf = min HzN*U
    prob.c                       =  [-HzN,1,1,1,2,2,2];

    % Cone constraints
    % Additional thrust constraints
    % u1^2 + u2^2 + u3^2 <= u4^2
    prob.cones.type              =  zeros(1,Num);
    prob.cones.sub               =  reshape(circshift(reshape(linspace(1,NumU*Num,NumU*Num)',NumU,[])',1,2)',1,[]);
    prob.cones.subptr            =  linspace(1,NumU*(Num-1)+1,Num);
    
    % Linear constraints
    % Terminal constraints
    % |HrN*U - HrN*Upre + Rpre| <= DeltaR
    % |HvN*U - HvN*Upre + Vpre| <= DeltaV
    a1                           =  [[HrN;HvN;-HrN;-HvN],[-eye(NumY);-eye(NumY)]];
    
    % Thrust magnitude constraint [0.5,1.0]
    % Tmin*Exp(-z) <= u4 <= Tmax*Exp(-z) -> Tmin*Exp(-zpre) <= u4 <= Tmax*Exp(-zpre)
    a2                           =  sparse((1:Num),NumU*(1:Num),ones(1,Num),Num,NumU*Num+NumY);
    
    % Thrust tile constraint
    % atan(sqrt(u1^2+u3^2)/u2^2) <= GammaT OR [u1,u2,u3]*ey >= u4*cos(GammaT)
    % -u2 + u4*cos(GammaT) <= 0  
    % [0,-1,0,cos(GammaT),0, 0,0,0,...
    %  0, 0,0,0,0,-1,0,cos(GammaT),...]
    a4                           =  sparse(reshape([(1:Num);(1:Num)],1,[]),2*(1:2*Num),repmat([-1,cos(GammaT)],1,Num),Num,NumU*Num+NumY);
    
    % Final mass constraint
    % mf > mdry -> z0 + HzN*U > mdry
    a5                           =  [HzN,zeros(1,NumY)];
    
    prob.a                       =  [a1;a2;a4;a5];
    
    % Upper bounds
    RightTerms                   =  sysModelLandingCoord3DMatrix0(Xpre);
    X(:,4:6)                     =  X(1,4:6) + kappa2*CoeffiA*RightTerms;
    X(:,1:3)                     =  X(1,1:3) + kappa2*X(1,4:6).*(tau+1) + kappa2*CoeffiA*(X(:,4:6) - X(1,4:6));
    buc1                         =  [-(X(end,1:6)'-Ytarg);(X(end,1:6)'-Ytarg)];
    buc2                         =  Isp*massrate*1.0*exp(-Xpre(:,7));
    buc4                         =  zeros(Num,1);
    buc5                         =  DryMass;
    
    % Lower bounds
    blc1                         = -inf*ones(2*NumY,1);
    blc2                         =  Isp*massrate*0.5*exp(-Xpre(:,7));
    blc4                         = -inf*ones(Num,1);
    blc5                         = -inf;

    prob.buc                     =  [buc1;buc2;buc4;buc5];
    prob.blc                     =  [blc1;blc2;blc4;blc5];

    % no trust region required
   
    % Call mosekopt solver
    [~,res]                      =  mosekopt('minimize echo(0)',prob);
    
    if strcmp(res.rcodestr, 'MSK_RES_OK') && abs(res.sol.itr.xx(1)) > 1E-6
        Z  =  res.sol.itr.xx;  
        U  =  reshape(Z(1:end-NumY),NumU,[])';
    else
        disp('Failure-Infeasible'); outputSimu.Flag = 0; break;
    end

    % States and control in column vector form
    XCol                         =  reshape(Xpre',[],1);
    UCol                         =  reshape(U',[],1);

    % AA parameters settings
    % mMax = 0 for P-SCP
    % mMax = 1 for AA-P-SCP
    % mMax >= 2 may not show better performance than mMax = 1.
    % Another setting can be given by mMax = 1,  iMax = 5,  aTol = 1E-6 for higher efficiency
    mMax                         =  2; iMax  =  100; aTol  =  0.1;
    
    % AA-Picard iterations
    XCol                         =  AndAcc(@PicardIteration,XCol,UCol,kappa2,mMax,iMax,aTol);
    X                            =  reshape(XCol,[],Num)';

    iter                         =  iter + 1;
    if  sum(isnan(X))            >= 1
        disp('Failure-Picard-NaN'); 
        outputSimu.Flag = 0;  break;
    end
    
    if  iter                     >  50 
        disp('Failure-OverMaxIter'); 
        outputSimu.Flag = 0;  break;
    end

    if  norm(X(:,1:3)-Xpre(:,1:3),inf) < 1  &&  norm(X(:,4:6)-Xpre(:,4:6),inf) < 0.1
        if abs(sqrt(sum(U(:,1:3).^2,2))-U(:,4)) < 1E-2 
            disp('Success!');  disp(['Iteration numbers��', num2str(iter)]);
            outputSimu.Flag = 1;  break;
        end
    end
    
end
toc
outputSimu.CPUtime               =  toc;
outputSimu.iter                  =  iter;
if  outputSimu.Flag  ==  1
    t                            =  (Tf+T0)/2 + (Tf-T0)/2*tau;
    Param.t                      =  t;
    Param.U                      =  U;
    OptionSet                    =  odeset('RelTol',1E-13,'AbsTol',1E-13,'MaxStep',1E-2);
    [~,xODE]                     =  ode45(@sysModelLandingCoord3D,[T0,Tf],X0',OptionSet,Param);

    disp(['Position error�� ',num2str(norm(xODE(end,1:3)-Ytarg(1:3)'))]);
    disp(['Velocity error�� ',num2str(norm(xODE(end,4:6)-Ytarg(4:6)'))]);
    
    outputSimu.FinalMass         =  exp(xODE(end,7));
    outputSimu.PosError          =  norm(xODE(end,1:3)'-Ytarg(1:3));
    outputSimu.VelError          =  norm(xODE(end,4:6)'-Ytarg(4:6));

end

