%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%

function  globalParam         =  globalParamSetting()

globalParam.d2r               =  pi/180;
globalParam.r2d               =  180/pi;

Re                            =  6378135;
g0                            =  9.79831;
mu                            =  3.986012E14;
Omegae                        =  7.292E-5;
J                             =  1.62395E-3;

Ae                            =  6378140;
Be                            =  6356755;

globalParam.dim_Re            =  Re;
globalParam.dim_g0            =  g0;
globalParam.dim_mu            =  mu;
globalParam.dim_Omegae        =  Omegae;
globalParam.dim_Ae            =  Ae;
globalParam.dim_Be            =  Be;
globalParam.dim_p0            =  101325;
globalParam.J                 =  J;

globalParam.nondim_Re         =  1;
globalParam.nondim_g0         =  1;
globalParam.nondim_mu         =  1;
globalParam.nondim_Omegae     =  0.05881128538171;
globalParam.nondim_Ae         =  6378140/Re;
globalParam.nondim_Be         =  6356755/Re;

