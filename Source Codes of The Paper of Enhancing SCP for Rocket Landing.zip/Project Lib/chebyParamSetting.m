function chebyParam  =  chebyParamSetting(NumCheby)

chebyParam.NumCheby  = NumCheby;
% Discrete times
chebyParam.tau       = fliplr(cos((0:NumCheby).*pi./NumCheby));
% Matrix R
chebyParam.R         = diag([1,1./2./(1:NumCheby)]);
% Matrix S
S                    = (tril(ones(NumCheby+1),-1) - tril(ones(NumCheby+1),-2)) ...
                     - (triu(ones(NumCheby+1), 1) - triu(ones(NumCheby+1), 2));
S(1,1)               = 1;
S(1,2)               = -1/2;
S(1,end)             = (-1)^(NumCheby+1)*1/(NumCheby-1);
K                    = (2 : NumCheby-1);
S(1,3:end-1)         = (-1).^(K+1).*(1./(K-1) - 1./(K+1));
chebyParam.S         = S;
% Matrix T
chebyParam.T         = ChebyshevPolynomial((0:NumCheby)',chebyParam.tau);
% Matrix V
chebyParam.V         = diag([1,2*ones(1,NumCheby-1),1]./NumCheby);
%
% Matrix TT
chebyParam.TT        = ChebyshevPolynomial((0:NumCheby),chebyParam.tau');
% Matric VV
chebyParam.VV        = diag([1/2,ones(1,NumCheby)]);
%
chebyParam.Sdot      = eye(NumCheby+1) - (triu(ones(NumCheby+1),2) - triu(ones(NumCheby+1),3));
chebyParam.Rdot      = diag(1./2./(1:NumCheby+1));
chebyParam.TTdot     = ChebyshevPolynomial((1:NumCheby+1),chebyParam.tau') ...
                     - ChebyshevPolynomial((1:NumCheby+1),-ones(NumCheby+1,1));
%
chebyParam.CoeffiA   =  chebyParam.TTdot*chebyParam.Rdot*chebyParam.Sdot*chebyParam.T*chebyParam.V;

end

function Tk = ChebyshevPolynomial(k,tau)
Tk = cos(bsxfun(@times,k,acos(tau)));
end

