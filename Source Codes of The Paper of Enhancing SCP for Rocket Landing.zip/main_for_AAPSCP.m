%-------------------------------------------------------------------------%
% Above Matlab-v2018a
%-------------------------------------------------------------------------%
clc
clear
close all

currentPath = pwd;
addpath(genpath(currentPath));

global globalParam modelParam chebyParam

globalParam                    =  globalParamSetting();
modelParam                     =  modelParamSetting();

N                              =  50;
chebyParam                     =  chebyParamSetting(N-1);

CPUtime                        =  zeros(1000,1);
Iter                           =  zeros(1000,1);
FinalMass                      =  zeros(1000,1);
PosError                       =  zeros(1000,1);
VelError                       =  zeros(1000,1);
FailureNum                     =  zeros(1000,1);

for  i                         =  1:1000
    
    % Initial Guess
    % 0-Randomly Generated
    % 1-Constant Profile
    % 2-Linearly Interpolated
    initFlag                   =  0;
    
    % Initial Condition
    X0                         =  [1800,5000,0,-260,-450,5,log(23000)];
    
    % TrajOptimization
    outputSolver               =  trajOptimAAPSCP(N,X0,initFlag);
    Flag                       =  outputSolver.Flag;
    
    if  Flag    == 1
        CPUtime(i)             =  outputSolver.CPUtime;
        Iter(i)                =  outputSolver.iter;
        FinalMass(i)           =  outputSolver.FinalMass;
        PosError(i)            =  outputSolver.PosError;
        VelError(i)            =  outputSolver.VelError;
    else
        FailureNum(i)          =  1;     
    end
    
end
disp(['Success Rate = ', num2str(1-sum(FailureNum)/1000)]);
save('resultTraj-AA-P-SCP.mat','CPUtime','Iter','FinalMass','PosError','VelError');
rmpath(genpath(currentPath));

