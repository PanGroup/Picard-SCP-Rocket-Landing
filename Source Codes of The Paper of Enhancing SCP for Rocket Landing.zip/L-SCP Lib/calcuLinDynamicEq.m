%-------------------------------------------------------------------------%
% @brief        ���Ի�����ѧ����
% @param[in]    tau    ʱ������
% @param[in]    X      ״̬����
% @param[in]    U      ��������
% @param[out]   Mz = F; z = [u0,u1,...un,x0,x1,...,xn,tf]
% @author       Lance
% @date         2021.4.24
%-------------------------------------------------------------------------%
function  [M,F]         =  calcuLinDynamicEq(tau, X, U, T0, Tf)

Num                     =  size(tau,1);
NumX                    =  size(X,2);
NumU                    =  size(U,2);

M                       =  zeros(NumX*(Num-1),NumX*Num+NumU*Num);
F                       =  zeros(NumX*(Num-1),1);
dtau                    =  tau(2) - tau(1);

for  i                  =  1:Num

    [Fx, Fu, b]         =  calcuFxFuFt(tau(i), X(i,:)', U(i,:)', T0, Tf);
    
    if  i               == 1
        
        M(NumX*(i-1)+1:NumX*i,1:NumU)                     =  dtau/2*Fu;
        M(NumX*(i-1)+1:NumX*i,NumU*Num+1:NumU*Num+NumX)   =  dtau/2*Fx + eye(NumX);
        F(NumX*(i-1)+1:NumX*i)                            = -dtau/2*b;
        
    elseif  i           == Num
        
        M(NumX*(i-2)+1:NumX*(i-1),NumU*(i-1)+1:NumU*i)                    =  dtau/2*Fu;
        M(NumX*(i-2)+1:NumX*(i-1),NumU*Num+NumX*(i-1)+1:NumU*Num+NumX*i)  =  dtau/2*Fx - eye(NumX);
        F(NumX*(i-2)+1:NumX*(i-1))  =  F(NumX*(i-2)+1:NumX*(i-1))-dtau/2*b;
    
    else
        
        M(NumX*(i-2)+1:NumX*i,NumU*(i-1)+1:NumU*i)                    =  [dtau/2*Fu; dtau/2*Fu];
        M(NumX*(i-2)+1:NumX*i,NumU*Num+NumX*(i-1)+1:NumU*Num+NumX*i)  =  [dtau/2*Fx-eye(NumX);dtau/2*Fx+eye(NumX)];
        F(NumX*(i-2)+1:NumX*i)  =  F(NumX*(i-2)+1:NumX*i)-[dtau/2*b; dtau/2*b];
        
    end
    
end


