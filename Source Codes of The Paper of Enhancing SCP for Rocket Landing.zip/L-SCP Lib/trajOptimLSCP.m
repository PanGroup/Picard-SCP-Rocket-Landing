%-------------------------------------------------------------------------%
% @brief         Linearization-based SCP for rocket landing trajectory optimization
% @author        Lance
% @date          2021.11.24
%-------------------------------------------------------------------------%
function  outputSimu             =  trajOptimLSCP(N,X0,initFlag)
global  modelParam
% Global parameters
% model parameters
massrate                         =  modelParam.massrate;
Isp                              =  modelParam.GroundIsp;
DryMass                          =  modelParam.dryMass;

% max glide-slope angle|max tilt angle
GammaR                           =  modelParam.GammaR;
GammaT                           =  modelParam.GammaT;

%% Trajectory Optimization
NumY                             =  6;
NumX                             =  7;
NumU                             =  4;

% Terminal conditions
Ytarg                            =  [0, 1, 0, 0, -1, 0]';

tau                              =  linspace(0,1,N)';
Num                              =  size(tau,1);

% Initial conditions
T0                               =  0;
Tf                               =  30;
% load('InitCondition.mat','Tf','X0');

% Set initial guess
if   initFlag                    == 0
    % Randomly Generated Initial Guess
    b1 =  5000;  b2 =  1000;  b3 =  5000;
    Xinit                        =  zeros(Num,NumX);
    Xinit(1,:)                   =  X0;
    Xinit(2:end,1:3)             =  2*(rand(Num-1,3)-1/2).*b1;
    Xinit(2:end,4:6)             =  2*(rand(Num-1,3)-1/2).*b2;
    Xinit(2:end,7)               =  log(23000 + 2*(rand(Num-1,1)-1/2)*b3);
    Uinit                        =  zeros(Num,NumU);
    
elseif initFlag                  == 1
    % Constant Profile
    Xinit                        =  repmat(X0,Num,1); 
    Uinit                        =  zeros(Num,NumU); 
    
elseif initFlag                  == 2
    % Linear Interpolation
    Xinit                        =  interp1([0;1],[X0;[Ytarg;log(DryMass)]'],tau');
    Uinit                        =  zeros(Num,NumU);
 
else
    % Error
    disp('Error in initial Guess!');
    
end

X                                =  Xinit;
U                                =  Uinit;

iter                             =  0;
tic
while true
    
    Xpre                         =  X;
    Upre                         =  U;
    Tfpre                        =  Tf;
    
    % Linearized dynamic equations M*z = F
    [M,F]                        =  calcuLinDynamicEq(tau,Xpre,Upre,T0,Tfpre);
    
    % Linearized terminal constaints A*Xf = b
    [A,b]                        =  calcuLinTerminalCons(Xpre(end,:)');
    
    % clear MOSEK
    clear prob;
    
    % Performance index z = [u0,u1,...un,x0,x1,...,xn]
    prob.c                       =  [zeros(1,NumU*Num+NumX*Num-1),-1,1,1,1,2,2,2];
    
    % Cone constraints
    % Additional thrust constraints
    % u1^2 + u2^2 + u3^2 <= u4^2
    prob.cones.type              =  zeros(1,Num);
    prob.cones.sub               =  reshape(circshift(reshape(linspace(1,NumU*Num,NumU*Num)',NumU,[])',1,2)',1,[]);
    prob.cones.subptr            =  linspace(1,NumU*(Num-1)+1,Num);
    
    % Linear constraints
    % Dynamic constraint
    lc2                          =  [M,zeros(NumX*(Num-1),NumY)];
    
    % Initial condition
    lc3                          =  [zeros(NumX,NumU*Num),eye(NumX),zeros(NumX,NumX*(Num-1)+NumY)];
    
    % Terminal constraint
    lc4                          =  [zeros(NumY,NumU*Num+NumX*(Num-1)),A,-eye(NumY);
                                     zeros(NumY,NumU*Num+NumX*(Num-1)),A, eye(NumY)];
    
    % Thrust magnitude constraint [0.5,1.0]
    % Tmin*Exp(-z) <= u4 <= Tmax*Exp(-z) -> Tmin*Exp(-zpre) <= u4 <= Tmax*Exp(-zpre)
    lc5                          =  sparse((1:Num),NumU*(1:Num),ones(1,Num),Num,NumU*Num+NumX*Num+NumY);
    
    % Thrust tile constraint
    % atan(sqrt(u1^2+u3^2)/u2^2) <= GammaT OR [u1,u2,u3]*ey >= u4*cos(GammaT)
    % -u2 + u4*cos(GammaT) <= 0
    % [0,-1,0,cos(GammaT),0, 0,0,0,...
    %  0, 0,0,0,0,-1,0,cos(GammaT),...]
    lc6                          =  sparse(reshape([(1:Num);(1:Num)],1,[]),2*(1:2*Num),repmat([-1,cos(GammaT)],1,Num),Num,NumU*Num+NumX*Num+NumY);
    
    prob.a                       =  [lc2;lc3;lc4;lc5;lc6];
    
    % Lower bounds
    blc2                         =  F;
    blc3                         =  Xinit(1,:)';
    blc4                         =  [-inf(NumY,1);b];
    blc5                         =  Isp*massrate*0.5*exp(-Xpre(:,7));
    blc6                         = -inf*ones(Num,1);
    prob.blc                     =  [blc2;blc3;blc4;blc5;blc6];
    
    % Upper bounds
    buc2                         =  F;
    buc3                         =  Xinit(1,:)';
    buc4                         =  [b;inf(NumY,1)];
    buc5                         =  Isp*massrate*1.0*exp(-Xpre(:,7));
    buc6                         =  zeros(Num,1);
    prob.buc                     =  [buc2;buc3;buc4;buc5;buc6];
    
    % Trust-region constraints
    prob.blx                     =  [-100*ones(NumU*Num,1) + reshape(Upre',[],1);...
                                      repmat(-[10000*ones(3,1); 10000*ones(3,1); 10],Num,1) + reshape(Xpre',[],1);...
                                      0;0;0;0;0;0];
    prob.bux                     =  [ 100*ones(NumU*Num,1) + reshape(Upre',[],1); ...
                                      repmat( [10000*ones(3,1); 10000*ones(3,1); 10],Num,1) + reshape(Xpre',[],1); ...
                                      inf;inf;inf;inf;inf;inf];
    % MOSEK solver
    [~,res]                      =  mosekopt('minimize echo(0)',prob);
    
    if strcmp(res.rcodestr,        'MSK_RES_OK') && abs(res.sol.itr.xx(1)) > 1E-6
        Z                        =  res.sol.itr.xx;
        U                        =  reshape(Z(1:NumU*Num),NumU,[])';
        X                        =  reshape(Z(NumU*Num+1:end-NumY),NumX,[])';
    else
        disp('Failure-Infeasible');   
        outputSimu.Flag = 0;  break;
    end

    iter                         =  iter + 1;
    if  iter                     >  30
        disp('Failure-OverMaxIter');  
        outputSimu.Flag = 0;  break;
    end
    
    if  norm(X(:,1:3)-Xpre(:,1:3),inf)<1 && norm(X(:,4:6)-Xpre(:,4:6),inf)<0.1
        if abs(sqrt(sum(U(:,1:3).^2,2))-U(:,4)) < 1E-2 
        disp('Success!'); disp(['Iteration numbers��', num2str(iter)]);
        % disp(max(abs(sqrt(sum(U(:,1:3).^2,2))-U(:,4))));
        outputSimu.Flag = 1;  break;
        end
    end
    
end
toc
outputSimu.CPUtime               =  toc;
outputSimu.iter                  =  iter;

if  outputSimu.Flag  ==  1
    
    t                            =  T0 + (Tf-T0)*tau;
    Param.t                      =  t;
    Param.U                      =  U;
    OptionSet                    =  odeset('RelTol',1E-13,'AbsTol',1E-13,'MaxStep',1E-2);
    [~,xODE]                     =  ode45(@sysModelLandingCoord3D,[T0,Tf],X0',OptionSet,Param);

    disp(['Position error�� ',num2str(norm(xODE(end,1:3)-Ytarg(1:3)'))]);
    disp(['Velocity error�� ',num2str(norm(xODE(end,4:6)-Ytarg(4:6)'))]);

    outputSimu.FinalMass         =  exp(xODE(end,7));
    outputSimu.PosError          =  norm(xODE(end,1:3)'-Ytarg(1:3));
    outputSimu.VelError          =  norm(xODE(end,4:6)'-Ytarg(4:6));
    
end
