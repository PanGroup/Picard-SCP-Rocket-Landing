%-------------------------------------------------------------------------%
% @brief                       ���㶯��ѧ����Jacobian����
% @param[in]                   tauk     ʱ������
% @param[in]                   Xk       ��ǰʱ��״̬��
% @param[in]                   Uk       ��ǰʱ�̿�����
% @param[in]                   T0       ��ʼʱ��
% @param[in]                   Tf       �ն�ʱ��
% @param[out]                  Fx       dFdX
% @param[out]                  Fu       dFdU
%-------------------------------------------------------------------------%
function  [Fx, Fu, b]          =  calcuFxFuFt(tauk, Xk, Uk, T0, Tf)
global globalParam modelParam
%% ȫ�ֲ���
Re                             =  globalParam.dim_Re;
mu                             =  globalParam.dim_mu;

% ������ģ�Ͳ���
Sref                           =  modelParam.Sref;                 
Isp                            =  modelParam.GroundIsp;

% ����״̬����������
Pos                            =  Xk(1:3);
Vel                            =  Xk(4:6);
Z                              =  Xk(7);
U1                             =  Uk(1);
U2                             =  Uk(2);
U3                             =  Uk(3);
U4                             =  Uk(4);

% ��½�����ʸ������½�����ϵ�µķ���(����)
RVect0                         =  [0,Re,0]';

% ��½���������ϵ�µ�����ǰλ�ã�����ʸ�������ľ�
RVect                          =  bsxfun(@plus,Pos,RVect0);
Rad                            =  norm(RVect);

% �������ٶ���
gVect                          = -mu./Rad.^3.*RVect;

% �����߶��ٶȲ���
h                              =  Rad - Re;
V                              =  norm(Vel);
Rho                            =  calcuDensity(h); 

% �������ٶ���
p00                            =  0.878;
p10                            =  0.007; 
p01                            =  1.116; 
p11                            = -0.002; 
p02                            = -0.406;

h(h < 1)                       =  1;
h(h > 10E3)                    =  10E3;
VV                             =  V;
VV(VV < 1)                     =  1;
VV(VV > 500)                   =  500;

% ����ϵ�����ٶ���ƫ���� Case 1
% CA                           =  p00 + p10*(h/1E3) + p01*(VV/340) + p11*(h/1E3)*(VV/340) + p02*(VV/340)^2;
% CA0                          =  p00 + p10*(h/1E3);
% CA1                          =  p01/340 + p11*(h/1E3)/340;
% CA2                          =  p02/340/340;
% acceD                        = -1/2*Rho.*Vel.*V.*Sref.*CA./exp(Z);
% acceD0                       = -1/2*Rho.*Sref./exp(Z);
% acceD1                       =  CA0*V+CA1*V*V+CA2*V*V*V;
% acceD2                       =  CA0+CA1*2*V+CA2*3*V*V;

% ����ϵ�������ٶ���ƫ���� Case 2
CA                             =  p00 + p10*(h/1E3) + p01*(VV/340) + p11*(h/1E3)*(VV/340) + p02*(VV/340)^2;
acceD                          = -1/2*Rho.*Vel.*V.*Sref.*CA./exp(Z);
acceD0                         = -1/2*Rho.*Sref./exp(Z);
acceD1                         =  CA*V;
acceD2                         =  CA;

ParAxParVx                     =  acceD0*(acceD1 + acceD2*Vel(1)*Vel(1)/V);
ParAxParVy                     =  acceD0*(acceD2*Vel(1)*Vel(2)/V);
ParAxParVz                     =  acceD0*(acceD2*Vel(1)*Vel(3)/V);
ParAxParZ                      = -acceD(1);

ParAyParVx                     =  acceD0*(acceD2*Vel(2)*Vel(1)/V);
ParAyParVy                     =  acceD0*(acceD1 + acceD2*Vel(2)*Vel(2)/V);
ParAyParVz                     =  acceD0*(acceD2*Vel(2)*Vel(3)/V);
ParAyParZ                      = -acceD(2);

ParAzParVx                     =  acceD0*(acceD2*Vel(3)*Vel(1)/V);
ParAzParVy                     =  acceD0*(acceD2*Vel(3)*Vel(2)/V);
ParAzParVz                     =  acceD0*(acceD1 + acceD2*Vel(3)*Vel(3)/V);
ParAzParZ                      = -acceD(3);

% �������ٶ���
acceThrust                     =  [U1,U2,U3]';

%% ����Jacobian����
NumX                           =  length(Xk);
NumU                           =  length(Uk);

dFdX                           =  zeros(NumX,NumX);
dFdX(1,1)                      =  0;
dFdX(1,2)                      =  0;
dFdX(1,3)                      =  0;
dFdX(1,4)                      =  1;
dFdX(1,5)                      =  0;
dFdX(1,6)                      =  0;
dFdX(1,7)                      =  0;
%
dFdX(2,1)                      =  0;
dFdX(2,2)                      =  0;
dFdX(2,3)                      =  0;
dFdX(2,4)                      =  0;
dFdX(2,5)                      =  1;
dFdX(2,6)                      =  0;
dFdX(2,7)                      =  0;
%
dFdX(3,1)                      =  0;
dFdX(3,2)                      =  0;
dFdX(3,3)                      =  0;
dFdX(3,4)                      =  0;
dFdX(3,5)                      =  0;
dFdX(3,6)                      =  1;
dFdX(3,7)                      =  0;
%
dFdX(4,1)                      = -mu/Rad^3 + 3*mu*RVect(1)^2/Rad^5;
dFdX(4,2)                      =  3*mu*RVect(1)*RVect(2)/Rad^5;
dFdX(4,3)                      =  3*mu*RVect(1)*RVect(3)/Rad^5;
dFdX(4,4)                      =  ParAxParVx;
dFdX(4,5)                      =  ParAxParVy;
dFdX(4,6)                      =  ParAxParVz;
dFdX(4,7)                      =  ParAxParZ;
%
dFdX(5,1)                      =  3*mu*RVect(2)*RVect(1)/Rad^5;
dFdX(5,2)                      = -mu/Rad^3 + 3*mu*RVect(2)^2/Rad^5;
dFdX(5,3)                      =  3*mu*RVect(2)*RVect(3)/Rad^5;
dFdX(5,4)                      =  ParAyParVx;
dFdX(5,5)                      =  ParAyParVy;
dFdX(5,6)                      =  ParAyParVz;
dFdX(5,7)                      =  ParAyParZ;
%
dFdX(6,1)                      =  3*mu*RVect(3)*RVect(1)/Rad^5;
dFdX(6,2)                      =  3*mu*RVect(3)*RVect(2)/Rad^5;
dFdX(6,3)                      = -mu/Rad^3 + 3*mu*RVect(3)^2/Rad^5;
dFdX(6,4)                      =  ParAzParVx;
dFdX(6,5)                      =  ParAzParVy;
dFdX(6,6)                      =  ParAzParVz;
dFdX(6,7)                      =  ParAzParZ;
%
dFdX(7,1)                      =  0;
dFdX(7,2)                      =  0;
dFdX(7,3)                      =  0;
dFdX(7,4)                      =  0;
dFdX(7,5)                      =  0;
dFdX(7,6)                      =  0;
dFdX(7,7)                      =  0;

Fx                             =  (Tf-T0)*dFdX;

dFdU                           =  zeros(NumX,NumU);
%
dFdU(1,1)                      =  0;
dFdU(1,2)                      =  0;
dFdU(1,3)                      =  0;
dFdU(1,4)                      =  0;
%
dFdU(2,1)                      =  0;
dFdU(2,2)                      =  0;
dFdU(2,3)                      =  0;
dFdU(2,4)                      =  0;
%
dFdU(3,1)                      =  0;
dFdU(3,2)                      =  0;
dFdU(3,3)                      =  0;
dFdU(3,4)                      =  0;
%
dFdU(4,1)                      =  1;
dFdU(4,2)                      =  0;
dFdU(4,3)                      =  0;
dFdU(4,4)                      =  0;
%
dFdU(5,1)                      =  0;
dFdU(5,2)                      =  1;
dFdU(5,3)                      =  0;
dFdU(5,4)                      =  0;
%
dFdU(6,1)                      =  0;
dFdU(6,2)                      =  0;
dFdU(6,3)                      =  1;
dFdU(6,4)                      =  0;
%
dFdU(7,1)                      =  0;
dFdU(7,2)                      =  0;
dFdU(7,3)                      =  0;
dFdU(7,4)                      = -1/Isp;

Fu                             =  (Tf-T0)*dFdU;


% ���Ի�������
F0                             =  zeros(NumX,1);
F0(1:3)                        =  (Tf-T0)*Vel;
F0(4:6)                        =  (Tf-T0)*(acceThrust + acceD + gVect);
F0(7)                          =  (Tf-T0)*(-U4./Isp);
b                              =  F0 - Fx*Xk - Fu*Uk;
