%-------------------------------------------------------------------------%
% Above Matlab-v2018a
%-------------------------------------------------------------------------%
clc
clear
close all
fclose all;

currentPath = pwd;
addpath(genpath(currentPath));

global globalParam modelParam

globalParam             =  globalParamSetting();
modelParam              =  modelParamSetting();

CPUtime                 =  zeros(1000,1);
Iter                    =  zeros(1000,1);
FinalMass               =  zeros(1000,1);
PosError                =  zeros(1000,1);
VelError                =  zeros(1000,1);
FailureNum              =  zeros(1000,1);

for i                   =  1:1000
    
    % Discrete Nodes
    N                   =  50;
    
    % Initial Guess 
    % 0-Randomly Generated 
    % 1-Constant Profile 
    % 2-Linearly Interpolated
    initFlag            =  0;
    
    % Initial Condition
    X0                  =  [1800,5000,0,-260,-450,5,log(23000)];
    
    % TrajOptimization
    outputSimu          =  trajOptimLSCP(N,X0,initFlag);
    Flag                =  outputSimu.Flag;

    if  Flag            == 1
        CPUtime(i)      =  outputSimu.CPUtime;
        Iter(i)         =  outputSimu.iter;
        FinalMass(i)    =  outputSimu.FinalMass;
        PosError(i)     =  outputSimu.PosError;
        VelError(i)     =  outputSimu.VelError;
    else
        FailureNum(i)   =  1;   
    end
end
disp(['Success Rate = ', num2str(1-sum(FailureNum)/1000)]);
save('result-L-SCP.mat','CPUtime','Iter','FinalMass','PosError','VelError');
rmpath(genpath(currentPath));
